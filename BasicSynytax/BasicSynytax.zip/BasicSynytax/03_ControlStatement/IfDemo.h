#pragma once

namespace IfDemo
{
	void Initialize();
	void Print();
	void Execute();
}



