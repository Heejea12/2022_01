#pragma once

namespace IncreasementDemo
{
	void Initialize();
	void Print();
	void Execute();
}