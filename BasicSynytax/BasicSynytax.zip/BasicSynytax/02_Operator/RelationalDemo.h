#pragma once

namespace RelationalDemo
{
	void Initialize();
	void Print();
	void Execute();
}