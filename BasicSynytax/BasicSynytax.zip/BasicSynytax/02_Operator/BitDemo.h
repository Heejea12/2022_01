#pragma once

namespace BitDemo
{
	void Initialize();
	void Print();
	void Execute();
}