#pragma once

namespace TernaryDemo
{
	void Initialize();
	void Print();
	void Execute();
}



