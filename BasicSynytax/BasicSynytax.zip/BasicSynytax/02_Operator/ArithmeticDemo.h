#pragma once

namespace ArithmeticDemo
{
	void Initialize();
	void Print();
	void Execute();
}