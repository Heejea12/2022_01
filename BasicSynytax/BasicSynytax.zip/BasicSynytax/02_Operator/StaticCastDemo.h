#pragma once

namespace StaticCastDemo
{
	void Initialize();
	void Print();
	void Execute();
}