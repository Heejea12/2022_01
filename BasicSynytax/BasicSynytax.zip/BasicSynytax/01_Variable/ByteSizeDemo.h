#pragma once

namespace ByteSizeDemo
{
	void Initialize();
	void Print();
	void Execute();
}