#pragma once

void Initialize();
void Print();
void Execute();