#pragma once

namespace EnumDemo
{
	void Initialize();
	void Print();
	void Execute();
}