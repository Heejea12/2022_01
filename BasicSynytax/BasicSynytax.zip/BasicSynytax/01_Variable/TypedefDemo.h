#pragma once

namespace TypedefDemo
{
	void Initialize();
	void Print();
	void Execute();
}