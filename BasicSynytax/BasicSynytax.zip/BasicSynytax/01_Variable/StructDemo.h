#pragma once

namespace StructDemo
{
	void Initialize();
	void Print();
	void Execute();
}