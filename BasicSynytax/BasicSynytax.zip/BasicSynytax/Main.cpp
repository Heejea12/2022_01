#include "stdafx.h"

int main()
{
	cout << "Hello" << endl;
	system("pause");

	return 0;
}