#include "stdafx.h"
#include "01_Variable/VariableDemo.h"
#include "01_Variable/ByteSizeDemo.h"
#include "01_Variable/EnumDemo.h"
#include "01_Variable/TypedefDemo.h"
#include "01_Variable/StructDemo.h"
#include "02_Operator/ArithmeticDemo.h"
#include "02_Operator/IncreasementDemo.h"

int main()
{
	IncreasementDemo::Execute();

	
	system("pause");
	return 0;
} 