#include "stdafx.h"
#include "01_Variable/VariableDemo.h"
#include "01_Variable/ByteSizeDemo.h"
#include "01_Variable/EnumDemo.h"
#include "01_Variable/TypedefDemo.h"
#include "01_Variable/StructDemo.h"

int main()
{
	StructDemo::Execute();

	
	system("pause");
	return 0;
} 